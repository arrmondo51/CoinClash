//
//  MarketCollectionViewCell.swift
//  CoinClash
//
//  Created by Mark Lagae on 7/19/17.
//  Copyright © 2017 Mark Lagae. All rights reserved.
//

import UIKit

class MarketCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView?
    @IBOutlet weak var titleLabel: UILabel?
    
}

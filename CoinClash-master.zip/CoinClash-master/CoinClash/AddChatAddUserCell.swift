//
//  AddChatAddUserCell.swift
//  CoinClash
//
//  Created by Mark Lagae on 6/23/17.
//  Copyright © 2017 Mark Lagae. All rights reserved.
//

import UIKit

class AddChatAddUserCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView?
    
}

//
//  ThumbnailPostCell.swift
//  CoinClash
//
//  Created by Mark Lagae on 6/6/17.
//  Copyright © 2017 Mark Lagae. All rights reserved.
//

import UIKit
import ParseUI

class ThumbnailPostCell: UICollectionViewCell {
    @IBOutlet weak var imageView: PFImageView?
}
